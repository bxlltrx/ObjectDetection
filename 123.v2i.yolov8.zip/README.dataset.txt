# 123 > 2024-07-03 8:30am
https://universe.roboflow.com/123-rg0hb/123-egldz

Provided by a Roboflow user
License: CC BY 4.0

